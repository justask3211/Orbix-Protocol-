# Orbix Protocol + Center — V6 delivery ledger

Status legend: `[x]` verified complete; `[~]` implemented but not independently verified/live; `[!]` blocked by an external prerequisite; `[ ]` not started. Never mark a blocked value-bearing gate complete by substituting a preview.

## Current release state

- [x] Preview UI/backend is deployed and browser-verified.
- [x] Solidity Center safety baseline passes 30 tests.
- [x] Python Center suite passes 105 tests.
- [x] Candidate token identity is verified on testnet, but transferability and burn semantics are not proven.
- [!] Funded ORBIX Center mode is intentionally disabled until the candidate token restriction and custody deployment gates pass.

Scope: Robinhood testnet 46630 only. This is an acceptance checklist, not a claim that items are complete. Existing V4 manual and V5 audit remain governing specifications. The two ORBIX addresses are distinct assets: the original vibevibe launch token is `0x0A7e1618582fbAd11c770670EF48048E236CC544`; the newly supplied Center candidate is `0x16C5451763eC2E0E7f041E2DB761A0491FdB6db1`. Never silently merge balances, liquidity or branding. Admin is the exact address `0x253db2d543b10c94918de97eb8499ee59ab9087e`, not a suffix check.

## Verified starting evidence

- Browser on production: cockpit renders, Center catalog renders 19 cards, but live hero still says eight formats. Repo differs from production.
- RPC answers chain ID 46630. New candidate returns `name=ORBIX`, `symbol=ORBIX`, `decimals=18`, bytecode exists, and admin wallet has a large balance.
- Read-only `eth_call` for a transfer of one token *from the admin wallet* reverted with selector `0xdb89e3f4`; `burn(uint256)` reverted. Neither transaction was broadcast. These results block assuming transferable/burnable token semantics. Determine exact reason before funding vault or promising conversion.
- Current Center preview remains simulated. No production custody contract is confirmed deployed for this token. Prior contract audit found serious refund, funding and settlement vulnerabilities.

## Gate A — inventory, research, threat model

- [ ] A01 Verify both token addresses on the correct chain and record bytecode hashes and deployers.
- [ ] A02 Obtain verified candidate token source/ABI or reconstruct only the functions required for integration.
- [ ] A03 Explain transfer revert `0xdb89e3f4` from verified source; test transferability by `eth_call` to ordinary and contract recipients.
- [ ] A04 Verify allowance, transferFrom, permit and burn behavior without moving funds.
- [ ] A05 Determine whether transfer tax, max-wallet, pause, blacklist, graduation or launch restrictions exist.
- [ ] A06 Verify candidate token total supply, admin balance and distribution.
- [ ] A07 Identify actual candidate-token liquidity on Orbix AMM and external routers; record reserves.
- [ ] A08 Prove executable swaps at bounded size/impact rather than assuming a synthetic exchange rate.
- [ ] A09 Inventory homepage, Discover, Swap, Pools, Bridge, Launch, Staking, NFT and Marketplace modules.
- [ ] A10 Inventory Center catalog, wizard, lobby, every 19-game stage, results, Vault and claim paths.
- [ ] A11 Audit mobile widths, keyboard flow, reduced motion, contrast and wallet dialogs in a browser.
- [ ] A12 Write a threat model for custody, signer, backend, admin, user wallet and third-party router.
- [ ] A13 Define the chain's testnet-only release policy and mainnet refusal checks.
- [ ] A14 Record an honest baseline test run and exact production API/build IDs.

## Gate B — identity and governance

- [ ] B01 Verify exact admin wallet ownership via nonce/domain/chain-bound signed login.
- [ ] B02 Reject every admin API mutation without a fresh validated session.
- [ ] B03 Rate-limit auth nonce requests and enforce one-time use and expiry.
- [ ] B04 Add server-side admin audit log with actor, old/new value, timestamp and chain ID.
- [ ] B05 Put custodian privileges behind a Safe or explicitly document restricted EOA testnet risk.
- [ ] B06 Implement two-step/timelocked ownership transfer where possible.
- [ ] B07 Design signer rotation with existing-room authorization continuity.
- [ ] B08 Add an emergency pause that cannot seize user balances.
- [ ] B09 Separate admin pricing authority from result-signing authority.
- [ ] B10 Snapshot pricing and treasury per published room; changes affect only new rooms.
- [ ] B11 Set caps and validation for creator charge and joiner charge.
- [ ] B12 Add admin readback UI that shows actual on-chain/config values, not local defaults.

## Gate C — on-chain custody and economics

- [x] C01 Write a failing test that creator cannot self-refund a consumed publication fee.
- [ ] C02 Bind publication intent to creator, room/config hash, chain, vault, price, nonce and deadline.
- [ ] C03 Create one-way consumed/refundable/refunded transitions linked to authorized cancellation.
- [ ] C04 Enforce withdrawal delay and available-vs-committed accounting.
- [ ] C05 Verify exact-balance ERC-20 deposits and reject fee-on-transfer/rebasing semantics.
- [ ] C06 Require signed-wallet payment for creator fees; backend never transfers user funds itself.
- [x] C07 Require reward funding before registration can open.
- [ ] C08 Declare required reward inventory by `(kind, contract, tokenId)` and verify every reserve.
- [ ] C09 Track native ETH, ERC-20, ERC-721 and ERC-1155 rewards by typed asset.
- [ ] C10 Validate NFT ERC-165 interfaces, reject mismatched entitlement kinds.
- [ ] C11 Track entry liabilities separately from reward inventory and protocol fees.
- [ ] C12 Snapshot entry token, amount, beneficiary and refund policy per round.
- [ ] C13 Support free join with zero custody requirement.
- [ ] C14 Support creator-sponsored joiner ORBIX fee as a distinct liability.
- [ ] C15 Support player-paid ORBIX platform join fee through wallet-signed payment.
- [ ] C16 Support creator-selected ERC-20 entry payment through escrow, not an arbitrary address.
- [ ] C17 Support native ETH entry payment only with exact payable accounting.
- [ ] C18 Prevent duplicate entry, wrong wallet, replay, chain mismatch and room-cap races.
- [ ] C19 Bind event receipt and finality to server admission; reject a submitted-but-unmined hash.
- [x] C20 Enforce settlement after playEnd and after server-authoritative terminal outcome.
- [ ] C21 Bind EIP-712 settlement to config hash, signer epoch, allocations and deadline.
- [x] C22 Make reward claims wallet-bound and proof-bound; mark claimed before transfer.
- [ ] C23 Ensure one failed recipient cannot lock unrelated winners' claims.
- [ ] C24 Define expired-claim grace and recovery policy; expose it before room creation.
- [ ] C25 Implement pull refunds after cancellation or settlement failure deadline.
- [ ] C26 Fuzz conservation across funding, joins, fees, claims, cancellations and refunds.
- [ ] C27 Fuzz malicious ERC-20/NFT receiver callbacks and reentrancy attempts.
- [ ] C28 Test zero/dust/overflow/rounding/decimals and reserve exhaustion.
- [ ] C29 Pin all fund-moving contract addresses/config before deploying to testnet.
- [ ] C30 Obtain independent review before turning on funded public flows.

## Gate D — conversion and ORBIX token integration

- [ ] D01 Distinguish launch-token ORBIX from candidate Center ORBIX in UI and APIs.
- [ ] D02 Disable burn controls until candidate token's actual burn method is proven.
- [ ] D03 Disable value-bearing vault deposits until actual transfer to vault passes simulation and a small isolated-wallet test.
- [ ] D04 Display live wallet balance/allowance for the chosen token and clear network mismatch.
- [ ] D05 Require explicit wallet confirmation and show recipient/amount before every approval or charge.
- [ ] D06 Prefer bounded exact approval, with ability to revoke; never approve an arbitrary router.
- [ ] D07 Build a route allowlist and independent quote oracle/impact warning for candidate ORBIX.
- [ ] D08 Quote exact-output creator entry token including slippage and gas costs.
- [ ] D09 Set user-chosen max input, min output and finite deadline; do not silently trade.
- [ ] D10 Verify pool liquidity and quote freshness at execution time.
- [ ] D11 Isolate conversion from custody and reward claim paths; failed swap leaves user funds intact.
- [ ] D12 Prove no conversion route exists if liquidity is absent, and offer direct token payment.
- [ ] D13 Reconcile transaction receipts/events, replacements and reorgs before server credit.
- [ ] D14 Display transparent rate, fees, output token and price impact in the creator and join flows.

## Gate E — backend and claims

- [x] E01 Replace short claim-id prefix with random opaque 128-bit+ reference and unique index.
- [x] E02 Validate entire code/checksum, reject prefixes and ambiguous lookups.
- [x] E03 Authenticate claimant wallet before disclosing reward details/proof.
- [x] E04 Return indistinguishable not-found/wrong-wallet responses to unauthenticated callers.
- [ ] E05 Preserve wallet-bound Merkle entitlement; reference is convenience, not bearer authority.
- [ ] E06 Export durable proof receipt so claim works during API outage.
- [ ] E07 Make ledger write PENDING until mined confirmation and reconciled event.
- [ ] E08 Persist per-room frozen economic config and asset identity.
- [ ] E09 Expose funding status and time windows directly from chain state.
- [ ] E10 Refuse funded-mode startup without valid addresses, chain ID, asset checks and signer.
- [ ] E11 Add integration tests for two-wallet create/join/finish/claim and refunds.
- [ ] E12 Keep preview rooms isolated from funded balances and label them honestly.

## Gate F — all-game hint policies

- [ ] F01 Introduce versioned typed hint schemas and immutable config hashes.
- [ ] F02 Number Hunt: off/private/public higher-lower feedback with player/number attribution.
- [ ] F03 Live Quiz: category/elimination hint without answer leakage.
- [ ] F04 Memory Match: bounded tile reveal without persistent secret leak.
- [ ] F05 Token Catch: safe lane/tempo cue.
- [ ] F06 Reaction Duel: timer/commit progress without opponent move reveal.
- [ ] F07 Puzzle Sprint: bounded move suggestion.
- [ ] F08 Hash Hunt: difficulty/progress cue, not the solution.
- [ ] F09 Boss Raid: team phase/weakness cue.
- [ ] F10 RPS Duel: commit/reveal progress only.
- [ ] F11 Reward Grid: bounded proximity cue.
- [ ] F12 Token-Logo Bingo: call history hint.
- [ ] F13 Pattern Recall: bounded replay hint.
- [ ] F14 Typing Sprint: accuracy/pace hint.
- [ ] F15 Maze Race: directional clue within fixed budget.
- [ ] F16 Level Runner: checkpoint cue.
- [ ] F17 Contract Detective: relevant evidence clue.
- [ ] F18 MEV Rush: simulated sequence cue without private target leak.
- [ ] F19 Idle Rig: efficiency cue.
- [ ] F20 Airdrop Quest: remaining-condition cue.
- [ ] F21 Test private/public reconnection, hint budgets, spam and transcript fairness.

## Gate G — visual product quality

- [ ] G01 Establish distinctive brand tokens for Center and cockpit; document type, color and spacing.
- [ ] G02 Make Center the unmistakable main product in homepage hero and primary navigation.
- [ ] G03 Replace stale/misleading “on-chain rewards” preview copy with mode-specific truth.
- [ ] G04 Improve catalog information hierarchy, grouping, search and empty states.
- [ ] G05 Upgrade game cards with consistent artwork, clear game length/players and rules.
- [ ] G06 Rebuild creator wizard with progressive disclosure and live room preview.
- [ ] G07 Explain free, creator-sponsored, and player-paid modes without jargon.
- [ ] G08 Show reward funding status and exact claim policy before join.
- [ ] G09 Build admin console with signed wallet gate and readback-confirmed controls.
- [ ] G10 Redesign room lobby/ready screen, stage/HUD, results and claim flow coherently.
- [ ] G11 Integrate candidate token identity in Discover/Swap without confusing existing launch ORBIX.
- [ ] G12 Surface actual pair availability and conversion disabled states honestly.
- [ ] G13 Refine Bridge copy to distinguish test ETH lane and unrelated xORBIX OFT lane.
- [ ] G14 Ship 375px/768px/1440px responsive checks and no horizontal overflow.
- [ ] G15 Verify touch targets, keyboard focus, contrast, reduced motion and error recovery.
- [ ] G16 Run real browser clicks, network and console audits on every named route.

## Gate H — deploy and handoff

- [ ] H01 Full Foundry, Python and Vite test/build runs are green with counts recorded.
- [ ] H02 Local Anvil cross-language funded flow passes with hardened contracts.
- [ ] H03 Compile and bytecode-verify each contract artifact against deployed runtime.
- [ ] H04 Deploy isolated testnet contracts only after Gates C/D pass and token transfers work.
- [ ] H05 Read back chain ID, token, vault, escrow, registry, owner, signer, fees and policy.
- [ ] H06 Execute a minimal isolated-wallet deposit, publication, join, settlement, claim and refund.
- [ ] H07 Configure Railway addresses and flags explicitly; do not activate unfunded pathways.
- [ ] H08 Deploy Center/backend then site; wait for final Railway deployment status.
- [ ] H09 Verify live rendered app in a real browser including SPA hydration and responsive states.
- [ ] H10 Verify exact API state and transaction receipts after changes.
- [ ] H11 Record deployment IDs, explorer links, contract addresses, commits and rollback path.
- [ ] H12 Clearly label remaining gated work; never claim planned features are live.

### 2026-10-02 addendum — D5 Live Quiz hints

- QuizRules gains `hints: off|on` and `hint_eliminations: 1..3` (per-question budget).
- QuizEngine gains a server-side `hint` action: privately eliminates ONE wrong choice per use; every eliminated index is verified against the answer key before release, so the cue can never point at the answer. Budget enforced per player per question; patch is a public counter only, the elimination itself rides `private`. Snapshot round-trips `hintsUsed`.
- Wizard: Live Quiz hint panel (off/on + eliminations-per-question) and defaults; buildConfig coerces `hints`/`hint_eliminations` per schema.
- Registry: `live-quiz` HintPolicy marked implemented (kind `elimination`, private audience).
- Evidence: `PYTHONPATH=~/vibeswap center/.venv/bin/pytest tests` 133/133 green (8 new in test_quiz_hints.py incl. non-leak invariant, budget, privacy, snapshot, after-window, scores-unchanged). `tsc -b --noEmit` exit 0; `npm run build` exit 0 (1.11s). Commit 90bc00aa.

### 2026-10-02 addendum 2 — D6 Memory Match hints

- MemoryRules gains `hints: off|on` and `hint_budget: 1..5` (per-player, per-round).
- MemoryEngine gains a server-side `hint` action: privately reveals ONE hidden matching pair (two verified indices from the secret layout) to the asking player; never touches matched cards, never exposes the board. Hard per-player budget; hints cost no moves and cannot change scores. `hintsLeft` snapshot round-trips.
- Wizard: Memory Match hint panel (off/on + reveals-per-player) + defaults. Registry policy v2 marked implemented.
- Evidence: pytest 141/141 green (8 new in test_memory_hints.py incl. pair-actually-matches, exposure cap, budget, privacy, no-score-impact, snapshot). tsc exit 0; vite build exit 0. Commit 4c7b532b.

### 2026-10-02 addendum 3 — D8 duel commit/reveal invariants

- Reaction Duel engine already shares only phase/commit-reveal status; new tests pin the non-leak contract: commit patches carry zero cleartext choices, public state stays choice-free until BOTH players reveal and the engine resolves, a partial reveal exposes only the revealer's own move (in the patch, never the other's), history appears only post-resolution, and salts/preimages are never published.
- Registry: reaction-duel round-progress policy description tightened, v2.
- Evidence: pytest 147/147 green (6 new in test_duel_hints.py). Commit f44ac28f.

### 2026-10-02 addendum 4 — D10 Hash Hunt throughput feed

- HashHuntEngine tracks per-player server-verified attempt volume (`attempts`, counted only on real hash evaluations, incl. rejected proofs) and publishes `attemptRates {attempts, valid}` plus truthful `difficultyBits`/`target` in public state. No solution nonce, partial preimage, or hash leaks through the feed; attempts survive snapshot round-trip.
- Evidence: pytest 153/153 green (6 new in test_hash_hunt_hints.py). Commit 0cc1b181.

### 2026-10-02 addendum 5 — D11 Boss Raid feed invariants

- Boss Raid's co-op hint surface (shared health/phase/weakness window + aggregate contribution + hit counts) is now pinned by tests: the feed shows only shared raid state, a player's private payload carries exclusively their own hit data, no pre-outcome damage/slain leak, oversized client power rejected, contribution cap and rate cap hold server-side.
- Evidence: pytest 159/159 green (6 new in test_boss_hints.py). Commit 6813b577.

### 2026-10-02 addendum 6 — D9 Puzzle Sprint hints

- PuzzleRules gains `hints off|on`, `hint_budget 1..10`, `hint_move_penalty 0..10`. PuzzleEngine gains a private `hint` action suggesting ONE legal tile (adjacent to the blank on the current board, deterministically the smallest) — never a solution path. Each use consumes budget and adds the penalty to the score (score = moves + penalty), so hint-assisted play cannot beat pure play. Snapshot round-trips budget + penalty.
- Wizard: Puzzle Sprint hint panel (off/on + hints-per-player + move penalty) + defaults; registry policy v2.
- Evidence: pytest 167/167 green (8 new in test_puzzle_hints.py incl. legality-on-current-board, played suggestion succeeds, path-non-leak shape, budget, penalty, privacy, snapshot). tsc exit 0; vite build exit 0. Commit 55a579a6.

### 2026-10-02 addendum 7 — D7 Token Catch, release-one hint ladder COMPLETE

- **Real leak fixed**: CatchEngine's `recent` public window previously published spawns up to +500ms in the FUTURE with lane and point values — a bot could pre-position before spawns fell. The window now contains only ALREADY-FALLEN spawns (last 300ms); the existing 250ms server-side catch tolerance covers latency, and future lanes/timings/hazards stay secret. Pinned by test.
- Registry: token-catch policy v2 implemented (kind `lane-tempo`). Wizard copy already described the intended style truthfully.
- Evidence: pytest 174/174 green (6 new in test_catch_hints.py + registry updates). tsc exit 0; vite build exit 0. Commit 5a5c87db.
- Release-one hint ladder (D4-D11) is now complete: number-hunt, live-quiz, memory-match, token-catch, reaction-duel, rps-duel, puzzle-sprint, hash-hunt, boss-raid all server-safe and test-pinned. Later-catalog feeds (D12-D22) remain honestly marked unimplemented.

### 2026-10-02 addendum 8 — E3 conservation invariants (E-section, 2x priority)

- New `test/center/CenterGamePotInvariants.t.sol` pins the formal accounting properties: I1 custody >= liabilities (tokenCommitted never exceeds contract balance, checked across every lifecycle step); I2 sweepDust can never move committed value (max-amount sweep attempt leaves treasury untouched); I3 no double payout (one-time claim nonces + settle digest replay rejected with exact revert); I4 exact conservation (rake + creator cut + winner payout + retained liability = total entry fees, verified to the wei in AUTO and MANUAL flows, and refund path returns custody to zero).
- Evidence: forge 79/79 tests green (4 new invariants). Commit 09bae0f9.

### 2026-10-02 addendum 9 — P1 token identity layer (trust primitive)

- New `center/token_identity.py`: TokenInspector reads name()/symbol()/decimals() via eth_call, checks bytecode presence (EOA = blocked), and detects burn-selector presence in bytecode as "possible-owner-opt-in" ONLY — burn is never auto-enabled. Verdict vocabulary is conservative: entry_ok requires on-chain-verifiable sane ERC-20 identity; unknown/reverting code is blocked by default (matching the fee-on-transfer/unknown-hook custody rule). No "trusted" concept exists.
- API: GET /api/center/v1/token/{address} returns the verdict (422 invalid address, 503 rpc unreachable) for the UI trust badge.
- Evidence: pytest 183/183 green (12 new: 5 decoding/classification in test_token_identity.py, 2 API in test_token_endpoint.py, plus suite). Commit 38ae6113.

### 2026-10-02 addendum 10 — C4 partial route audit (live, Playwright)

- Cockpit routes swept on the LIVE deployment at 1440x900 and 390x844 via Playwright: swap, pools, bridge, launch, staking, marketplace all render with ZERO horizontal overflow at both widths (scrollWidth == innerWidth on every route) and ZERO console errors/warnings across the sweep.
- NFT route: no nav entry found by the sweep (label mismatch or gated route) — flagged for the next pass rather than assumed fine.
- Screenshots: audit-cockpit-1440.png, audit-cockpit-390.png (full page). Center routes were verified earlier (center-1440-desktop.png, center-390-mobile.png, center-create-wizard-1440.png): 0 overflow, 0 console errors.
- Still open under C4: per-route state coverage (empty/loading/error), room stage-by-stage sweep, keyboard/focus pass per route, tablet 768 sweep.

### 2026-10-02 addendum 11 — D12/D13 grid + bingo feeds

- D12 Reward Grid: private proximity hint answering only coarse Manhattan-distance bands (near/mid/far) to the nearest hidden reward tile — never a tile, direction, or row/column, so a hint cannot identify a slot (3 bands << 36 tiles). Hard 2-use per-player budget, fairness-transcript log, snapshot-safe. Truthfulness test verifies the band matches the real geometry.
- D13 Bingo: call-history feed invariants pinned — public calls array grows as a prefix, future pool order never in public state, forged board claims refused server-side.
- Registry: reward-grid + logo-bingo policies v2 implemented; later-catalog list shrinks accordingly.
- Evidence: pytest 190/190 green (9 new in test_grid_bingo_hints.py). Commit d00e0b7d.

### 2026-10-02 addendum 12 — D14/D15 recall + typing feeds

- D14 Pattern Recall: private bounded-replay hint re-sends EXACTLY the already-visible prefix (`sequence[:step]`) and nothing beyond it — proven equal to `public_state()["visibleSequence"]` and strictly shorter than the full sequence. Budget 2/round, snapshot-safe.
- D15 Typing Sprint: private pace cue derived ONLY from the asker's own server-verified keystroke log (median inter-key ms of the last 5 keys + pace flag: warming-up/sprinting/steady/slowing/stalled). A player who never typed gets "warming-up" with keys=0 — the cue mathematically cannot describe another player. Budget 5, snapshot-safe.
- Registry: pattern-recall + typing-sprint v2 implemented.
- Evidence: pytest 198/198 green (8 new in test_recall_type_hints.py). Commit 8c20482b.

### 2026-10-02 addendum 13 — D16-D21: FULL 19-format hint catalog complete

- D16 maze-race: private directional clue (coarse compass direction from the asker's own cell that reduces exit distance, or "no-improving-move"); layout already public, hint only saves pathfinding effort; budget 3, snapshot-safe.
- D17 level-runner: private checkpoint telemetry from the asker's own server-authoritative run (distance, lane, crash state); obstacle stream stays secret until each reveal; budget 3.
- D18 contract-detective: ONE static evidence cue per round (which line to focus on) — cannot encode the correct choice; explicitly not an audit verdict; 1 use.
- D19 mev-rush: simulated queue position + own captures, explicitly labeled simulated; no live mempool claim; budget 3.
- D20 idle-rig: server-clock-verified own efficiency readout (rate, next-upgrade cost, earned); no off-chain earning implication.
- D21 airdrop-quest: wallet-bound remaining/completed quest lists; provably cannot issue an entitlement (test asserts achieved stays empty after a hint).
- Registry: ALL 19 formats now implemented; the old "honestly unimplemented" test is replaced by a regression guard asserting every format stays implemented.
- Evidence: pytest 208/208 green (12 new in test_late_hints.py). tsc exit 0; vite build exit 0. Commit 7b3304c1.

### 2026-10-02 addendum 14 — E5 audit chain hardening

- E5 audit confirmed solid (nonce+wallet-signature sessions, single-use signed admin proofs with replay refusal, exact-wallet check, audit log on every accepted mutation). Hardened the remaining gap: the admin audit log now has a tamper-evident SHA-256 hash chain — every entry commits to its predecessor's hash (prev_hash + entry_hash columns); `Store.verify_audit_chain()` recomputes oldest-first and pinpoints the broken entry.
- API: GET /admin/audit/verify (admin-gated) returns {ok, entries, head} or {ok:false, brokenAt, reason}.
- Tests prove a silent UPDATE of history and a row DELETE both break verification at the exact entry.
- Evidence: pytest 215/215 green (5 new in test_audit_chain.py). Commit 911339d8.

### 2026-10-02 addendum 15 — E13 adversarial suite

- New `test/center/CenterGamePotAdversarial.t.sol`:
  - ReentrantNFT adversary fires onERC721Received DURING the auto reward payout and attempts (1) a re-settle of a room and (2) a double-claim of the same locked NFT. Both fail; the NFT reaches the winner exactly once; the room stays settled and a second settle is refused.
  - SkimmingToken (keeps 50% of every transfer) as reward asset: lockRewardERC20 reverts ZeroAmount on partial delivery and books nothing — the pot can never owe more than it holds.
  - SkimmingToken as ENTRY asset: enter() books exactly what arrived (20e18 of a 40e18 sticker) in pot and tokenCommitted — fee-on-transfer truth, not sticker price.
- Evidence: forge 82/82 green (3 new). Commit cc633b10.

### 2026-10-02 addendum 16 — F2 transaction state machine

- New `center/tx_state.py`: full lifecycle unsigned -> signed -> submitted -> confirmed -> finalized (terminal) with failed/reorged branches. Rules enforced and test-pinned: room entry is admitted ONLY on a FINALIZED receipt (3 confirmations); receipts are evidence-verified (status, contract address, sender) with wrong-contract/wrong-sender -> FAILED; repeated receipts are idempotent (confirmation count updates in place, promoting CONFIRMED -> FINALIZED); a vanished receipt flips CONFIRMED/FINALIZED -> REORGED which blocks entry until the tx re-finalizes deeper; one intent = one row, one tx hash = one intent (case-insensitive duplicate rejection); every transition is timestamped with evidence in the row history.
- Evidence: pytest 225/225 green (10 new in test_tx_state.py). Commit 90d6743a.

### 2026-10-02 addendum 17 — F4 attacker-model suite

- Identity: WS `who` is bound server-side from a short-lived ticket (asserted against the handler source; no code path lets a payload set the acting identity). A forged action claiming another player's identity attributes to the SENDER in the server log and engine state.
- Injection inertness: client-supplied score/winner/targets/correct fields inside action payloads are inert; Number Hunt guesses attribute to the sender regardless of claimed "who"; Quiz answer correctness is decided only server-side (fabricated correct:true + score:5000 changes nothing).
- Entitlements: produced solely by engine.entitlements(); with no reward slots configured, even a verified winner yields zero payable slots; a hit closes the round engine-side, never client-side.
- Post-round forgery refused (ROUND_FINISHED).
- Evidence: pytest 231/231 green (6 new in test_attacker_model.py). Commit ac9728bb.

### 2026-10-02 addendum 18 — F5 pre-sign join disclosure

- Room lobby now shows an expanded "Before you join" panel above the join button, disclosing every term F5 requires BEFORE any signing: exact entry cost (vault points + joiner fee, who pays it), reward-mode truth (funded on-chain assets vs preview-points-only), payout authority and the frozen-at-publish pot split/claim deadline, the refund path (creator cancel -> exact-amount refunds; cancelled-room refund pointer), claim-deadline expiry and creator reclaim, and the network (Robinhood testnet 46630, gas is test ETH, never sign unread transactions).
- Typed reads from the server config (room.config.access/rewards); no client-side invention of terms.
- Evidence: tsc exit 0; vite build exit 0. Commit e7225110.

### 2026-10-02 addendum 19 — deploy path + F5 live check

- Deployment: this checkout has no git remote and no railway CLI; Railway builds from its own integration checkout, so today's commits (F5 disclosure, F4 suite, F2 state machine, E5 chain, E13 suite, token identity, hint ladder) reach production on the next Railway sync. Live site re-verified healthy (HTTP 200 on /center).
- F5 panel ships behind the frontend build; verification of the live panel requires the next Railway deploy of web/. Marked as shipped-in-code, pending-live until then — per the "deployment success is not feature success" rule.

### 2026-10-02 addendum 20 — DEPLOYED LIVE: all session work now on production

- Railway deploy (deploy 23600a3b SUCCESS, superseded by ef0fc11a SUCCESS on the orbixcore site service): full-repo upload from the linked checkout; two intermediate FAILED builds (bf0d2949, fe298473) were root-directory mismatches (Dockerfile path looked up as deploy/site/Dockerfile relative to archive root), fixed by uploading from the repo root with the freshly regenerated deploy/site bundle.
- Live verification (Playwright + bundle grep, real browser):
  - /center serves the NEW center bundle (index-B5bdAHvI.js) containing: "Before you join — read the room terms" (F5), "Eliminations per question" (quiz hint wizard), "Reveals per player" (memory hint wizard), "Hints per player" (puzzle hint wizard). All grep hits = 1.
  - 0 console errors/warnings on the live Center page.
  - Live URL: https://orbixcore.fun/center
- Backend service (orbix-center) was already on its own deploy train; the Python API changes (token identity endpoint, tx-state module, audit chain) deploy with that service's next sync.

### 2026-10-02 addendum 21 — GitHub + full stack live

- GitHub: repo justask3211/Orbix-Protocol- (renamed by owner from Tech; fine-grained token scoped to it, stored at ~/.orbix_github_env). Full monorepo pushed (422 files; node_modules/venvs/gitignored). CI: Foundry workflow restored after workflow-scope grant; fixed two CI failures — (1) forge fmt gate (normalized 24 files, tests still 82/82), (2) LayerZero npm contracts missing in CI (added pinned npm install step). CI now GREEN on main (run c50b1366).
- Backend deployed: orbix-center service (2edb9c98) deployment cda091da SUCCESS after gitignore had excluded web/dist (COPY target); verified LIVE:
  - GET /token/0x16C5...6db1 -> entry_ok TRUE, ORBIX, 18 decimals, burn not-detected (real on-chain readback against Robinhood testnet 46630!)
  - bad address -> 422; admin/audit/verify unauthenticated -> 401.
- Frontend already live since ef0fc11a (F5 + hint wizards).
- Full stack now live: cockpit + Center (orbixcore), Center API (orbix-center), source on GitHub with green CI.

### 2026-10-02 addendum 22 — Creator token binding contract (E6 creator-token flow)

- New `src/center/CreatorTokenGate.sol` implements the owner's creator-token system: creator binds their token CA + per-joiner token fee to a room (only when ORBIX joiner fees are creator-absorbed, enforced by the server); joiners approve once and the gate pulls THEIR token — joiner ORBIX untouched; creator-or-absorbed ORBIX stays on the server-side ledger as today.
- Mutable by design: updateBinding (fee/token swap) + setPaused emit events the backend logs. Pull-based custody (allowance required), one-entry-per-player, relayed join with EIP-191 signature binding (roomId, player, nonce), one-time nonce, admin/treasury rotation events.
- 15 new tests (CreatorTokenGate.t.sol): bind/update/pause/permissions, join pays treasury exactly, double-join + no-allowance + insufficient-balance rejections (failed join never marks joined), relayed join wrong-signer + replay + wrong-signer-nonce refusal, treasury rotation.
- Foundry: 97/97 green. Committed with the UI 100x pass (4c21c24b) and CI fixes.

## Delivery log — 2026-10-02

Mechanisms-first pass (2× core focus per A-to-Z plan), all evidence recorded:

- **CenterGamePot v2 (E8/E9)** — `src/center/CenterGamePot.sol` rewritten and test-proven:
  - settle() now verifies an authority signature over the full payout payload (winners, amounts, reward winners, reward indices) bound to contract address + chainId + roomId; digest replay-guarded. Empty sig = NotAuthority, malformed/mismatched = BadSignature.
  - claimWinnings()/claimReward() bound to (roomId, winner/amount/index, one-time nonce) + claim deadline; NonceReused on replay.
  - refundEntry() returns exactly what the entrant paid (per-entrant paidIn, fee-on-transfer truth), once, only on cancelled rooms.
  - AUTO mode pushes pot shares and locked ERC20/NFT rewards atomically at settlement; MANUAL mode records liabilities for signed pull claims.
  - Tests: `forge test` 75/75 green (7 CenterGamePot tests incl. unsigned-settlement rejection, over-pot rejection, nonce replay, conservation with creator share, refund-once, NFT auto-pay).
- **Typed hint policies (D3)** — new `center/games/hints.py`: versioned per-template HintPolicy (kind, audience public/private, budget, cost, honest `implemented` flag). Implemented for number-hunt (higher/lower), hash-hunt (difficulty/throughput), boss-raid (phase/weakness), bingo (call history), rps/reaction duel (commit/reveal progress), memory-match (bounded reveal, budget 2), puzzle-sprint (legal-move, budget 3). All later-catalog formats declare intended style with implemented=false so the UI stays truthful.
- **New tests** — `center/tests/test_hint_policies.py` (7): full catalog coverage, number-hunt public hint never leaks the target, private vs off behavior, honest unimplemented flags. Python suite: 124/124 green (`PYTHONPATH=~/vibeswap center/.venv/bin/pytest tests`).
- **Live browser audit (Playwright)** — orbixcore.fun/center verified at 1440 and 390px: skip link present, truthful reward-status banner, dynamic "19 game formats", no horizontal overflow at 390px (bodyScrollWidth 390), wallet controls inside header, wizard shows "number hunt hint policy" with higher/lower public/private control, 0 console errors. Screenshots: center-1440-desktop.png, center-390-mobile.png, center-create-wizard-1440.png.
- Honest status: CenterGamePot v2 is local/test-proven, NOT yet deployed to chain 46630 (funded paths stay gated pre-graduation, per V5 P4). Hint policies are server-side registry data; wiring per-later-game feeds into engines remains D5-D22 work.

## Delivery log — 2026-10-01 (session 20260929_022348)

Shipped, tested (117 Python tests green) and verified live at orbixcore.fun/center:

- **B02/B04/B09/B10/B11 (admin pricing backend)** — DONE: exact-wallet pricing authority
  (0x253d…9087e, full-address match), capped creator/joiner fees, fresh single-use signed
  admin proofs over a distinct signing domain, immutable per-room fee snapshots,
  append-only audit log. Endpoints: GET/PATCH /api/center/v1/admin/pricing, GET /admin/audit.
- **G09 (admin console)** — backend DONE (signed wallet gate + readback). Frontend admin
  page still pending (owner-gated).
- **G16 partial (real browser verification)** — top bar (single 50px sleek horizontal tab,
  seamless wallet + balance + pill Connect), wizard no-jump format picker (picked format
  collapses to a chip; change/continue buttons; compact 110px numeric fields), smooth
  digit-pad input (slots are the input, glow caret, pop-fill), card/button polish — all
  browser-verified on the deployed build.
- **H01 partial** — Python: 117 passed. Vite: build green. Foundry run not re-executed this session.
- **H08/H09 partial** — Railway deployments 28962928 & 704af5c8 SUCCESS (orbixcore svc);
  live SPA bundle hash-checked; header + wizard flows clicked through in a real browser.

Known blockers (unchanged, honestly gated):
- Candidate ORBIX 0x16C5…6db1 is bonding-curve locked pre-graduation (revert 0xdb89e3f4):
  transfers and burns revert, so funded custody/join-fee/conversion paths stay disabled.
- Remaining owner-gated: F04, E06, G01–G08, G10–G15, H02–H07 per original ledger.


## 2026-10-01 — FUNDED REWARDS LIVE (H07 closed)

- DepositVault (CenterVault) deployed on Robinhood testnet 46630: **0x33e0d64d1e894cd2bce673baeb0ff68153bd0aa3**
  (tx 0xc5b6eec7b7e3d74b97555d213867a54770d621f651036bb663150e13aeecbeeb, block 127003737)
- Reward token: FREE (0x9d6EA9FbEF2b244FB30f6E775f2DA3CC431b733e). Vault **FUNDED with 500,000 FREE**
  (tx 0xf3284c4a1babac21a7c2f511a908a9d56aff32417dbc491d17666d638750d0fd).
- Why FREE and not ORBIX: ORBIX 0x16C5...6db1 is a vibevibe.fun launchpad token still on its bonding
  curve (pre-graduation); every transfer/burn reverts until it graduates. Users who buy ORBIX on
  vibevibe can swap to FREE and deposit; when ORBIX graduates, CENTER_VAULT_TOKEN can be repointed
  with no contract change (the vault is single-token but the backend flag is a swap).
- Backend: env-driven OnchainVault in create_app (CENTER_REAL_BURN + CENTER_VAULT_TOKEN + CENTER_VAULT
  + CENTER_SIGNER_KEY + CENTER_RPC_URL), new GET /wallet/onchain-balance (live wallet + vault-credit
  balances read from chain, 15s TTL cache). JsonRpc sends a browser UA (RPC 403s plain clients).
- Frontend: top-bar pill shows live "X FREE" (polled 20s); Vault page shows credited + wallet
  balances with vault address + chain id.
- Railway env set on orbix-center (production): CENTER_REAL_BURN=true, CENTER_TESTNET_REWARDS=true,
  CENTER_VAULT_TOKEN, CENTER_VAULT, CENTER_ESCROW, CENTER_RPC_URL, CENTER_CHAIN_ID=46630,
  CENTER_VAULT_SYMBOL=FREE, CENTER_SIGNER_KEY=[set, redacted].
- Verified in browser: sign-in, top bar live balance, Vault panel "0 FREE credited / 1,250 FREE in
  wallet · vault 0x33e0…0aa3 · chain 46630" after sending 1,250 FREE to the demo wallet on-chain.
- Tests: 117/117 green.


## 2026-10-01 — CenterGamePot v1 deployed (entry pots + locked rewards + treasury)

User's custody model, implemented on-chain:
- **Treasury custody**: user deposits / reward inventory sit in contracts WE hold. The admin
  treasury wallet (0x253d...9087e) decides to hold or manually burn later — players used the
  token, we received it. The old Center suite's broadcast was a fork simulation (owner() reverts
  on live testnet), so a fresh contract was shipped.
- **CenterGamePot** `0x2acb02dcf0012d2ca98c8526dba78dad647b32f6` (tx 0xaa2508e6...e3417d):
  - `openRoom(roomId, payoutWallet, creatorShareBps, entryToken, entryAmount, mode, claimDeadline)`
    — creator picks the wallet the pot share goes to and its share (bps).
  - `enter(roomId)` — players pay the entry fee into the room pot.
  - `lockRewardERC20` / `lockRewardNFT` — creator locks a token or NFT reward; the contract
    holds it until settlement.
  - `settle(...)` — authority-signed. **AUTO mode**: pot shares AND locked rewards are pushed to
    winners at settlement. **MANUAL mode**: winners pull with an authority signature
    (`claimWinnings` / `claimReward`). Creator chooses per room.
  - `cancelRoom` + `refundEntry` (players made whole), `reclaimReward` after claim deadline.
  - `sweepDust` — treasury sweeps ONLY uncommitted surplus; pots and locked rewards are tracked
    in `tokenCommitted` and can never be swept. Protocol rake `feeBps` capped at 10%, currently 0.
  - Seeded with 50,000 FREE as reward inventory.
- DepositVault (0x33e0...0aa3) remains the creator-deposit path; GamePot handles per-room entry
  fees + rewards. 117/117 backend tests still green.
