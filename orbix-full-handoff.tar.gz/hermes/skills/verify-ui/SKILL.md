---
name: verify-ui-before-instructions
description: Use when giving website steps. Verify the page in a browser.
---

# Verify UI before giving instructions

NEVER give a user a URL/route/click-path without rendering it in a real browser first. A curl 200 proves nothing for SPAs — hash routes can 200 but render the wrong page (portalbridge.com/#/redeem renders Swap, not redeem).

## Workflow
1. browser_exec: new_tab(url), wait_for_load, sleep 2-5s (SPA hydration).
2. Read `js("document.body.innerText.slice(0,500)")` — confirm the page matches the claim.
3. Enumerate real actions: `js("[...document.querySelectorAll('a,button,[role=tab]')].map(e=>e.innerText+'::'+(e.getAttribute('href')||''))")`.
4. Wrong/404 route: load site home, use in-app search/nav; drive React inputs via native value setter + `new Event('input',{bubbles:true})` (plain fill_input doesn't register), then read resulting URL — give THAT url to the user.
5. browser_exec IS the headless browser (chromium-1243 available) — never claim verification is impossible.

## Why
User feedback 2026-09-28: gave /redeem (404), then #/redeem (rendered Swap) — user debugged my answer himself. 'You should be more advanced than me, not 10% satisfied.'

## Verified findings (Wormhole stuck funds, wallet 0x9867...b15e)
- portalbridge.com has NO redeem page (all routes → Swap UI).
- Redemption: wormholescan.io → search 'Search by Tx Hash' box → tx page shows TRANSACTION STATUS 'PENDING CLAIM' + RESUME button. Hash-URL form: /#/tx/<hash>?network=Mainnet.
- stuckfunds.eth.limo data can be stale (claimed 'expired signatures'; actual state PENDING CLAIM).
- Example tx: 0x06400a0d6a6bb2f68aee415d6795f9b8782c34f5e4822a6ce9c15af5799835af (Arbitrum→Celo, 1.5 USDC, VAA 23/0b240214.../254114).
