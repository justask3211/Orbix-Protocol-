---
name: web-design-guidelines
description: Review React/HTML/CSS UI for current Vercel Web Interface Guidelines compliance. Fetches the latest checklist, inspects target files, reports concise file:line findings, then fixes and rechecks.
---

# Vercel Web Interface Guidelines

Use for UI audits and implementation. Before every audit, retrieve the current checklist from `https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md`; do not rely on a stale copy. Inspect the specified files/pattern, cite findings as `path:line`, fix actionable issues, and rerun the review.

Check at minimum: semantic and keyboard-accessible controls; labels and form semantics; visible focus; paste support; loading/error states; reduced motion; transform/opacity-only animation; no `transition: all`; responsive safe areas and touch targets; deep links/URL state; robust long/empty content; image dimensions/lazy loading; dark-mode tokens; hydration-safe inputs; number/date localization; and active/hover states.

Do not claim compliance without reviewing source. Be concise and prioritize critical accessibility, interaction, correctness, then polish.
